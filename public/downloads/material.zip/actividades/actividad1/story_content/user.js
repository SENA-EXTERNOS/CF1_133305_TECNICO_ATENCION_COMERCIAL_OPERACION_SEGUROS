function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5vHNK6LsN67":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

